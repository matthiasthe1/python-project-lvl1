#!/usr/bin/env python
from brain_games.games import brain_progression


def main():
    brain_progression.game()


if __name__ == '__main__':
    main()
