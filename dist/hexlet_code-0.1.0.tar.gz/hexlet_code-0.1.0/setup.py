# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.games.brain_calc:main',
                     'brain-even = brain_games.games.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.games.brain_gcd:main',
                     'brain-prime = brain_games.games.brain_prime:main',
                     'brain-progression = '
                     'brain_games.games.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'Educational project (stage 1, Python course by hexlet.io )',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/matthiasthe1/python-project-lvl1/workflows/hexlet-check/badge.svg)](https://github.com/matthiasthe1/python-project-lvl1/actions)\n\n<a href="https://codeclimate.com/github/codeclimate/codeclimate/maintainability"><img src="https://api.codeclimate.com/v1/badges/a99a88d28ad37a79dbf6/maintainability" /></a>\n\n### brain-calc:\nhttps://asciinema.org/a/zvtrGLKJ2UgZb1rNIIg8X0yxt\n\n### brain-even:\nhttps://asciinema.org/a/7tsWCbOzeXzhQWUcFIlDDJUUQ\n\n### brain-gcd:\nhttps://asciinema.org/a/R5uo26PeckOJlKcYgmKAEq8Ik\n\n### brain-prime:\nhttps://asciinema.org/a/jZdFvtUgiu4e0Uk2n5i87X835\n\n### brain-progression:\nhttps://asciinema.org/a/ZYkSvWyhOxZvQ2pip8AeQeEhm\n\n\n',
    'author': 'Roman Anisimov',
    'author_email': 'r.anisimov.esq@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/matthiasthe1/python-project-lvl1',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
