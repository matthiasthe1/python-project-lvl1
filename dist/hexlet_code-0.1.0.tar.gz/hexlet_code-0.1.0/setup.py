# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.games.brain_gcd:main',
                     'brain-prime = brain_games.games.brain_prime:main',
                     'brain-progression = '
                     'brain_games.games.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'Educational project (stage 1, Python course by hexlet.io )',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/matthiasthe1/python-project-lvl1/workflows/hexlet-check/badge.svg)](https://github.com/matthiasthe1/python-project-lvl1/actions)\n\n[![Actions Status](https://github.com/matthiasthe1/python-project-lvl1/workflows/my-linter/badge.svg)](https://github.com/matthiasthe1/python-project-lvl1/actions)\n\n<a href="https://codeclimate.com/github/matthiasthe1/python-project-lvl1/maintainability"><img src="https://api.codeclimate.com/v1/badges/c0dd3185b671c247749c/maintainability" /></a>\n\n### brain-calc:\n<a href="https://asciinema.org/a/H1PlHFZFFVm5KanX7Bv7ZOSS2" target="_blank"><img src="https://asciinema.org/a/H1PlHFZFFVm5KanX7Bv7ZOSS2.svg" /></a>\n\n### brain-even:\n<a href="https://asciinema.org/a/SHBdZg1fmCy3wX5d2s4bHhN5L" target="_blank"><img src="https://asciinema.org/a/SHBdZg1fmCy3wX5d2s4bHhN5L.svg" /></a>\n\n### brain-gcd:\n<a href="https://asciinema.org/a/IW4HeghXXR84PdzkjAqFxE4dO" target="_blank"><img src="https://asciinema.org/a/IW4HeghXXR84PdzkjAqFxE4dO.svg" /></a>\n\n### brain-prime:\n<a href="https://asciinema.org/a/w6HLFcRzHFLbXINetvt68c4Of" target="_blank"><img src="https://asciinema.org/a/w6HLFcRzHFLbXINetvt68c4Of.svg" /></a>\n\n### brain-progression:\n<a href="https://asciinema.org/a/b6715pLjogV62OaasSPN6x057" target="_blank"><img src="https://asciinema.org/a/b6715pLjogV62OaasSPN6x057.svg" /></a>\n\n\n',
    'author': 'Roman Anisimov',
    'author_email': 'r.anisimov.esq@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/matthiasthe1/python-project-lvl1',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
